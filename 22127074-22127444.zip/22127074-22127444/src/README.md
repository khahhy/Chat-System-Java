# Chat-System-Java

Thiết kế giao diện:

Vào thư mục src:

chạy lệnh: ./mvnw.cmd exec:java -pl client

Với người quản trị:

Tên đăng nhập: admin1

Mật khẩu: password123

Với người dùng:

Tên đăng nhập: java

Mật khẩu: 2024